let equation = document.getElementById("eq");

const canvas = document.querySelector("canvas");
var w = canvas.width = window.innerWidth;
var h = canvas.height = window.innerHeight;
const ctx = canvas.getContext("2d");
const radius = w*0.35;
let frac,fracy;
//image parameters//	
 let img = new Image();
function preloadImage(url)
{
   img.src = url;
}
preloadImage("https://i.imgur.com/7Ud0wlv.png");

let verticalSlices = Math.round(img.height / 20);
let  maxHorizOffset = 2;
		
function drawSector(length,count){
	
	//image
	for (var i = 0; i < verticalSlices; i++)  
	{
    var horizOffset = getRandom(-Math.abs(maxHorizOffset), maxHorizOffset);
    ctx.drawImage(img, 
    0, 
    i * verticalSlices, 
    img.width, 
    i * verticalSlices + verticalSlices, 
    horizOffset + w - img.width, i * verticalSlices + h/2.3 -img.height/2, 
    img.width, 
    i * verticalSlices + verticalSlices);
	}
	//image text
	let fontArr = "bold 60px Sarpanch";
	ctx.font = fontArr;
  ctx.fillStyle ="black";
	ctx.fillText('माधव',w-img.width*0.8,h/3 + img.height/2 + h*0.2);
	
	// blue sector
	ctx.strokeStyle="black";
	ctx.lineWidth=2;
	ctx.beginPath();
	ctx.moveTo(w*0.1,h*0.9);
	ctx.lineTo(w*0.1+radius,h*0.9);
	ctx.stroke();
	ctx.beginPath();
	ctx.moveTo(w*0.1,h*0.9);
	ctx.lineTo(w*0.1+radius*Math.cos(Math.PI/4),h*0.9 - radius*Math.sin(Math.PI/4));
	ctx.stroke();
	
	//blue arc outer
	ctx.beginPath();
	ctx.arc(w*0.1,h*0.9,radius,-Math.PI/4,0);
	ctx.stroke();
	
	//blue arc angle
	ctx.beginPath();
	ctx.arc(w*0.1,h*0.9,radius*0.1,-Math.PI/4,0);
	ctx.stroke();
	
	//arc angle text
	ctx.font="20px Arial";
  ctx.fillStyle = "black";
	ctx.fillText("π/4",w*0.1 + radius*Math.cos(Math.PI/8)*0.15,h*0.9- radius*Math.sin(Math.PI/8)*0.15);
	
	//dynamic arc length
	ctx.strokeStyle = "#F73F0F";
	ctx.lineWidth = 10;
	ctx.beginPath();
	ctx.arc(w*0.1,h*0.9,radius,-length,0);
	ctx.stroke();
	
  //dynamic arm
  ctx.strokeStyle = "#2E5A67";
  ctx.lineWidth = 2;
  ctx.moveTo(w*0.1,h*0.9);
  ctx.lineTo(w*0.1+radius*Math.cos(length),h*0.9 - radius*Math.sin(length));
  ctx.stroke();
  
  //dynamic arc fill
  ctx.fillStyle = "rgba(215,141,15,0.3)";
  ctx.arc(w*0.1,h*0.9,radius,-length,0);
  ctx.fill();
  
	//dynamic arc text
// 	ctx.font="20px Arial";
//  ctx.fillStyle = "black";

// if(count==0)
//   fracy = "";
// else if(count==1)
//   fracy = "1";
// else if(count>1)
//   {
// if(count%2==0)
// fracy = fracy + "- \\frac{1}{" + (2*count-1).toString() + "}";
// else
// fracy = fracy +  "- \\frac{1}{" + (2*count-1).toString() + "}";
//   }

// ctx.fillText(frac,w*0.4 + radius*Math.cos(Math.PI/8)*0.15,h*0.9- radius*Math.sin(Math.PI/8)*0.15);

 
}
		
	

let sketchArr = [];
	sketchArr[0] = 0;
for(let i=0; i<100;i++)
	{
		
		sketchArr[i+1] = sketchArr[i] + Math.pow(-1,i%2)*1/(2*i +1);
	}

//background

let col = function(x, y, r, g, b) {
  ctx.fillStyle = "rgb(" + r + "," + g + "," + b + ")";
  ctx.fillRect(0, y, w,h);
}
let R = function(x, y, t) {
  return( Math.floor(192 + 64*Math.cos( (x*x-y*y)/300 + t )) );
}

let G = function(x, y, t) {
  return( Math.floor(192 + 64*Math.sin( (x*x*Math.cos(t/4)+y*y*Math.sin(t/3))/300 ) ) );
}

var B = function(x, y, t) {
  return( Math.floor(192 + 64*Math.sin( 5*Math.sin(t/9) + ((x-100)*(x-100)+(y-100)*(y-100))/1100) ));
}

let tree = 0;


//animation parameters		
let speed = 0.002;			
let pos = 0 ; 
let counter =0;
let slip =0;
	
function animate(){ 

	ctx.clearRect(0,0,w,h);
	requestAnimationFrame(animate);
 
  for(var x=0;x<=w;x++) {
    for(var y=0;y<=h;y++) {
      col(x, y, R(x,y,tree), G(x,y,tree), B(x,y,tree));
    }
  }
  tree = tree + 0.120;
  
	pos = sketchArr[counter];
	 if(counter==0)
   	frac = "";
 	else if(counter==1)
   	frac = "1";
 



	if(counter < 98)
		{
	 if(counter%2==0)
		 {
			 slip+=speed;
			 drawSector(pos + slip,counter);
			 if(pos + slip > sketchArr[counter+1] )
				 {
					 slip=0;
					 counter+=1;
           if(counter < 15)
             {
					 frac = frac + "+ \\frac{1}{" + (2*counter-1).toString() + "}";
					 katex.render(" \\frac{\\pi}{4} = " + frac, equation);
             }
        
					
						if(counter > 0 && counter < 3)
		{
			speed = speed*0.5;
		}
				 }

		 }
	 else
		{
			slip-=speed;
			drawSector(pos+slip,counter);
			if(pos+slip < sketchArr[counter+1])
				{
					slip=0;
					counter+=1;
          if(counter < 15){
          frac = frac + "- \\frac{1}{" + (2*counter-1).toString() + "}";
					katex.render(" \\frac{\\pi}{4} = " + frac, equation);
          }
        
						if(counter > 0 && counter < 3)
		{
			speed = speed*0.5;
		}

				}


		}
		}

	else
			{
				drawSector(Math.PI/4,0);
			}


  
//   if([Math.floor(temp)]<100)
//     {
//       if(temp<1) drawSector(temp,0);
//       else
//         {
//           speed = 0.005;
//         drawSector(sketchArr[Math.floor(temp)] + 0.003*Math.sin(temp*100/Math.floor(temp) +1),Math.floor(temp));
//         }
//     }
//   else 
// 	 {
//      drawSector(Math.PI/4);
//    }
// }
}
animate();

function replay(){
	pos =0; 
	counter =0; 
	slip =0;
	speed = 0.003;
}

function getRandom(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
	//pallette colors//
// #2E5A67
// #D78D0F
// #E4C821
// #E57719
// #F73F0F
//